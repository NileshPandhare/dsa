package com.demo.enums;

public enum Gender {
	male,female;

}
