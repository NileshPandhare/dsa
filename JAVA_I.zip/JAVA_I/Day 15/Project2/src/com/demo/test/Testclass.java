package com.demo.test;
import com.demo.packa.A;
import com.demo.packb.B;
public class Testclass {

	public static void main(String[] args) {
		A ob2=new A(20,"Manjiri");
		System.out.println(ob2);
		B ob1=new B("Sahil");
		System.out.println(ob1);
		

	}

}
