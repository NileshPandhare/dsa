package com.demo.test;
import java.util.Arrays;
import java.util.Scanner;

import com.demo.beans.MyArray;

public class TestMyArray {
public static void main(String[] args) {
	MyArray ob=new MyArray(5);
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<ob.getLength();i++) {
		System.out.println("enter number");
		int n=sc.nextInt();
		ob.add(n);
	}
	System.out.println(ob);
	//System.out.println(Arrays.toString(ob.add()));
	System.out.println("sum is: "+ob.getSum());
    ob.rotateArray(4);
	System.out.println(ob);
	System.out.println(Arrays.toString(ob.reverseArray(true)));
	System.out.println(ob.findMax());
}


}

